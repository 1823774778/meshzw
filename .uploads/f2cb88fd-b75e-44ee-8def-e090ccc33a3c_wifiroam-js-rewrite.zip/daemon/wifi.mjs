// wifi.mjs -- 本机 Wi-Fi 配置应用、漫游配置（802.11k/v/r、ft_mode、
// RSSI 预设与阈值）、无线回程、终端引导（BSS Transition）、固定 AP。
// 对照原版 wifiroamd.uc（5498 行）§8 划分的 wifi 模块函数逐字搬运，
// 行号见 spec.md §2。只 import lib/（util / shell / ubus 常量 /
// uci / store）；不 import 其他业务模块。
//
// 工厂：createWifi(ctx)，ctx = { S, bus, uci, shell, util, store }，
// S 是 core 持有的共享 state（字段名与 spec §1.2 逐字一致）。
// 需要调其他模块的函数时只经 ctx 注入的回调（localClients /
// deviceKey / pushEvent / clientNameOf / apDisplay /
// parseFdb）；未注入时用本模块内的原样 fallback（按原版逻辑抄，
// 见各 fallback 处的注释），不直接 import 其他业务模块。
//
// 固定 AP（pin）归属：pin_of / pin_apply 的唯一实现在 clients 模块
// （core 的 set_pin 与 ctx.pinApply 接的都是 clients）；本模块不自带
// pin 实现。pinTick / steerTick 读固定关系只经 ctx.pinOf（core 注入
// clients.pinOf），未注入时工厂直接抛 TypeError，不留第二份实现。
//
// 目标：Node 22.23.4，ESM，零 npm 依赖，只用 Node 核心模块。
// research-node-ubus.md §1.5 的禁用清单一条不用（见该文档表）。

import { existsSync, readdirSync, readFileSync } from 'node:fs';
import {
  cmdOutput as libCmdOutput,
  runProcess as libRunProcess,
  shellCommands,
  PROC,
} from '../lib/shell.js';
import {
  fieldAfter,
  hhmmMinutes,
  log,
  maccolon,
  macnorm,
  nowSeconds,
  randhex,
  sha256,
  toInt,
} from '../lib/util.js';
import { uci as defaultUci } from '../lib/uci.js';

// ------------------------------------------------------------- 常量（原版）
// STEER_COOLDOWN=60s 同一终端两次 BSS Transition 引导的最小间隔；
// MIN_STEER_ASSOC=20s 终端入网后至少稳定这么久才允许被引导；
// STEER_KICK_AFTER=3 连续 BTM 引导无果的次数，达到后强制断开让终端重新选 AP；
// STEER_KICK_COOLDOWN=1800s 同一终端两次强制断开的最小间隔；
// PIN_BAN_MS=120000 固定终端连错 AP 时 hostapd 禁入时长（毫秒）；
// PIN_KICK_COOLDOWN=30s 同一终端两次踢回目标 AP 的最小间隔。
export const STEER_COOLDOWN = 60;
export const MIN_STEER_ASSOC = 20;
export const STEER_KICK_AFTER = 3;
export const STEER_KICK_COOLDOWN = 1800;
export const PIN_BAN_MS = 120000;
export const PIN_KICK_COOLDOWN = 30;
export const BACKHAUL_SECTION = 'wifiroam_bh';
export const BACKHAUL_DEFAULT_SSID = 'wifiroam-bh';
export const MAX_EVENTS = 100;

// 漫游键（原版 ROAM_KEYS，14 个）：不在漫游组的 SSID 仅当其现含
// ieee80211r/k/v 任一键时才删除全部这些键。
export const ROAM_KEYS = [
  'ieee80211r', 'mobility_domain', 'ft_over_ds', 'ft_psk_generate_local',
  'nas_identifier', 'pmk_r1_push', 'r0kh', 'r1kh', 'reassociation_deadline',
  'ieee80211k', 'rrm_neighbor_report', 'rrm_beacon_report',
  'ieee80211v', 'bss_transition',
];

// 默认 fs 适配器：detect_self / local_iface_macs / self_uptime /
// precheck 读 /proc、/sys、/tmp/sysinfo、/etc/openwrt_release 与
// apk 存在性判断。测试可经 ctx.fs 注入同形适配器。
// readFile(path) -> string | null；glob(pattern) -> string[]；
// access(path) -> boolean。
const defaultFs = {
  readFile(path) {
    try {
      return readFileSync(path, 'utf8');
    } catch (_e) {
      return null;
    }
  },
  glob(pattern) {
    // 只服务 "/sys/class/net/*/address" 这一形；其余返回 []。
    const m = /^(\/[^*]*)\/\*(\/.*)$/.exec(pattern);
    if (!m) return [];
    let names = [];
    try {
      names = readdirSync(m[1]);
    } catch (_e) {
      return [];
    }
    const out = [];
    for (const n of names) {
      const p = `${m[1]}/${n}${m[2]}`;
      if (existsSync(p)) out.push(p);
    }
    return out;
  },
  access(path) {
    return existsSync(path);
  },
};

export function createWifi(ctx = {}) {
  const S = ctx.S ?? {};
  const bus = ctx.bus ?? null; // UbusClient（lib/ubus.js），可为 null（纯配置路径）
  const uci = ctx.uci ?? defaultUci;
  const shell = ctx.shell ?? {};
  const cmdOutput = typeof shell.cmdOutput === 'function' ? shell.cmdOutput : libCmdOutput;
  const runProcess = typeof shell.runProcess === 'function' ? shell.runProcess : libRunProcess;
  const fs = ctx.fs ?? defaultFs;

  // --- 跨模块回调（ctx 注入；未注入时用本模块的原样 fallback） ---
  // device_key：clients 模块的函数。fallback 按原版 device_key 逐字抄：
  // g 开头走 redirect 链（最多 16 跳），否则查 state.device_index。
  const deviceKey = typeof ctx.deviceKey === 'function'
    ? ctx.deviceKey
    : (v) => {
      const s = String(v ?? '').trim().toLowerCase();
      let key = /^g[0-9a-f]{12}$/.test(s) ? s : macnorm(s);
      if (key.startsWith('g')) {
        let guard = 0;
        while (S.aliases?.redirect?.[key] && guard++ < 16) key = S.aliases.redirect[key];
        return key;
      }
      return S.device_index?.[key] ?? key;
    };
  // push_event：core 的函数。fallback 按原版 push_event 抄：环形缓冲
  // 上限 MAX_EVENTS(100)，并 log。
  const pushEvent = typeof ctx.pushEvent === 'function'
    ? ctx.pushEvent
    : (type, mac, info, name) => {
      if (!Array.isArray(S.events)) S.events = [];
      S.events.push({ ts: nowSeconds(), type, mac: mac ?? '', name: name ?? '', info: info ?? '' });
      if (S.events.length > MAX_EVENTS) S.events = S.events.slice(S.events.length - MAX_EVENTS);
      log(`event ${type} ${mac ?? '-'} ${name ?? '-'} ${info ?? ''}`);
    };
  // pin_of：clients 模块的唯一实现（core 注入 clients.pinOf）。
  // pin 的写路径 pin_apply 只在 clients（set_pin 经 core 调它），
  // 本模块从不写 pin，因此只接 pinOf；未注入时 fail-fast，不留
  // 第二份 pin 实现。
  if (typeof ctx.pinOf !== 'function') {
    throw new TypeError('wifi: ctx.pinOf (clients.pinOf) is required');
  }
  const pinOf = ctx.pinOf;
  // local_clients：clients 模块的唯一终端数据源。
  const localClients = typeof ctx.localClients === 'function'
    ? ctx.localClients
    : () => ({});
  // client_name_of：终端展示名优先级：自定义别名 > 本机/对端主机名 >
  // 本网络名称表 > MAC。fallback 按原版抄（local 为本次已有客户端表）。
  const clientNameOf = typeof ctx.clientNameOf === 'function'
    ? ctx.clientNameOf
    : (mn, local) => {
      const key = deviceKey(mn);
      const al = S.aliases?.map?.[key] ?? S.aliases?.map?.[macnorm(mn)] ?? null;
      if (al?.name != null && al.name !== '') return al.name;
      const c = local?.[mn];
      if (c?.hostname != null && c.hostname !== '') return c.hostname;
      for (const p of Object.values(S.peers ?? {})) {
        const pc = p.clients?.[mn];
        if (pc?.hostname != null && pc.hostname !== '') return pc.hostname;
      }
      const n = S.net_names?.[mn];
      if (n?.hostname != null && n.hostname !== '') return n.hostname;
      return maccolon(mn);
    };
  // ap_display：本机返回 self.name，否则 peer 名，未知返回冒号 MAC。
  const apDisplay = typeof ctx.apDisplay === 'function'
    ? ctx.apDisplay
    : (mn) => {
      if (mn === macnorm(S.self?.mac)) return S.self?.name;
      const p = S.peers?.[mn];
      if (p) return p.info?.name ?? p.name ?? maccolon(mn);
      return maccolon(mn);
    };
  // parse_fdb：clients 模块的函数（ethernet_uplink_port 用）。
  // fallback 按原版 parse_fdb 逐字抄：`bridge fdb show`，空输出时回退
  // `brctl showmacs` + `brctl showstp` 端口名映射。
  const parseFdb = typeof ctx.parseFdb === 'function'
    ? ctx.parseFdb
    : () => {
      const out = {};
      const data = cmdOutput(shellCommands.bridgeFdbShow(S.brdev ?? 'br-lan'));
      if (data !== '') {
        for (const line of data.split('\n')) {
          const f = line.trim().split(' ');
          if (f.length < 3) continue;
          const mn = macnorm(f[0]);
          if (mn.length !== 12) continue;
          if (f.includes('self') || f.includes('permanent')) continue;
          const port = fieldAfter(f, 'dev');
          if (!port) continue;
          out[mn] = port;
        }
        return out;
      }
      const pnames = {};
      const stp = cmdOutput(shellCommands.bridgePortNames(S.brdev ?? 'br-lan'));
      for (const line of stp.split('\n')) {
        const m = /^([^\s]+) \(([0-9]+)\)/.exec(line);
        if (m) pnames[m[2]] = m[1];
      }
      const data2 = cmdOutput(shellCommands.brctlShowmacs(S.brdev ?? 'br-lan'));
      for (const line of data2.split('\n')) {
        const f = line.trim().split(/[ \t]+/);
        if (f.length < 3) continue;
        const mn = macnorm(f[1]);
        if (mn.length !== 12) continue;
        if (f[2] === 'yes') continue; // 网桥自身接口 MAC
        out[mn] = pnames[f[0]] ?? f[0];
      }
      return out;
    };

  // ubus 调用：原版 ubusc.call 为同步，失败返回 null/抛错（见 §9.22
  // 附近的讨论）；lib/ubus.js 的 call() 是 async 且失败时抛
  // UbusError。这里按原版调用点的兜底语义：detect_self /
  // wireless_uplink / self_info 路径上失败返回 null；ap_nr_self、
  // neighbor_sync、steer_tick、pin_tick 各自有 try/catch（原版同）。
  async function busCall(path, method, data) {
    if (!bus) return null;
    try {
      return await bus.call(path, method, data);
    } catch (_e) {
      return null;
    }
  }

  // 抛错版：steer_tick / pin_tick 原版在每次 hostapd 调用外包
  // try/catch，失败时只 log，不更新 steer_last / steer_tries /
  // kick_last / pin_last；若在此处吞掉错误，失败的引导会被误记
  // 为成功，故这几处必须用抛错版，让外层 catch 接住。
  async function busCallThrow(path, method, data) {
    if (!bus) throw new Error('wifi: no ubus client');
    return bus.call(path, method, data);
  }

  // ------------------------------------------------------------ 自检/探测
  // lan_broadcast：由 LAN IP 与掩码算广播地址；解析失败返回
  // 255.255.255.255。ucode 无 >>> 运算符，0xffffffff 在 int64 下为
  // 正数，>> 等效逻辑右移；JS 用 >>> 保持等价。
  function lanBroadcast(ip, mask) {
    const parts = String(ip ?? '').split('.');
    if (parts.length !== 4) return '255.255.255.255';
    let v = 0;
    for (const p of parts) v = ((v << 8) | (toInt(p) & 255)) >>> 0;
    const m = toInt(mask);
    const hostmask = (m > 0 && m < 32) ? (0xffffffff >>> m) : 0xff;
    const b = (v | hostmask) >>> 0;
    return `${(b >>> 24) & 255}.${(b >>> 16) & 255}.${(b >>> 8) & 255}.${b & 255}`;
  }

  // 本机所有网络接口 MAC：用于把 AP 自身的接口（如无线回程 STA 口）
  // 从“下挂终端”中排除，避免 AP 被同时计为终端导致数量虚高。
  function localIfaceMacs() {
    const out = {};
    for (const f of fs.glob('/sys/class/net/*/address')) {
      if (f.includes('/lo/')) continue;
      const m = macnorm(String(fs.readFile(f) ?? '').trim());
      if (m.length === 12 && m !== '000000000000') out[m] = true;
    }
    return out;
  }

  // 探测本机：读 network.interface.lan 状态、/sys 接口 MAC、
  // /etc/openwrt_release、hostname、model，填 state.self 与 state.bcast、
  // nonce（randhex(16)）。（spec §9.7：各字段回落值以原文为准。）
  async function detectSelf() {
    const st = await busCall('network.interface.lan', 'status');
    const dev = st?.device ?? st?.l3_device ?? 'br-lan';
    S.brdev = dev;
    const ip = st?.['ipv4-address']?.[0]?.address ?? null;
    const mask = st?.['ipv4-address']?.[0]?.mask ?? 24;
    S.bcast = lanBroadcast(ip, mask);
    let mac = String(fs.readFile(`/sys/class/net/${dev}/address`) ?? '').trim();
    if (macnorm(mac).length !== 12) {
      for (const f of fs.glob('/sys/class/net/*/address')) {
        if (f.includes('/lo/')) continue;
        const m = String(fs.readFile(f) ?? '').trim();
        if (macnorm(m).length === 12) { mac = m; break; }
      }
    }
    const rel = fs.readFile('/etc/openwrt_release') ?? '';
    let fw = 'OpenWrt';
    const m = /DISTRIB_DESCRIPTION='([^']+)'/.exec(rel);
    if (m) fw = m[1];
    S.self = {
      mac: String(mac).toUpperCase(),
      ip,
      hostname: String(fs.readFile('/proc/sys/kernel/hostname') ?? 'OpenWrt').trim(),
      model: String(fs.readFile('/tmp/sysinfo/model') ?? 'OpenWrt device').trim(),
      firmware: fw,
      nonce: randhex(16),
      ifaces: localIfaceMacs(),
    };
    S.self.name = S.cfg?.name !== '' ? S.cfg.name : S.self.hostname;
    log(`self: ${S.self.mac} ${S.self.ip ?? '?'} ${S.self.name}`);
  }

  // 无线回程检测：优先看本插件托管的 STA 接口，其次看其它已关联的 STA。
  // 仅当 STA 真实关联（iw link 显示 Connected）才算无线上行，避免把
  // “配置了但没连上”的接口误报成回程。
  async function wirelessUplink() {
    const ws = (await busCall('network.wireless', 'status')) ?? {};
    let fallback = null;
    for (const r of Object.values(ws)) {
      for (const ifc of r.interfaces ?? []) {
        if (ifc.config?.mode !== 'sta' || !ifc.ifname) continue;
        const link = cmdOutput(shellCommands.iwDevLink(ifc.ifname));
        if (link.indexOf('Connected to') < 0) continue;
        const m = /Connected to ([0-9a-fA-F:]+)/.exec(link);
        const s = /signal:\s*(-?[0-9]+)/.exec(link);
        const info = {
          type: 'wireless', port: ifc.ifname,
          ssid: ifc.config?.ssid ?? null,
          bssid: m ? m[1].toLowerCase() : null,
          rssi: s ? toInt(s[1]) : null,
        };
        if (ifc.section === BACKHAUL_SECTION) return info;
        if (!fallback) fallback = info;
      }
    }
    return fallback;
  }

  function detectUplink() {
    const out = cmdOutput(shellCommands.ipRouteDefault());
    const words = String(out.split('\n')[0] ?? '').trim().split(' ');
    const gw = fieldAfter(words, 'via');
    const dev = fieldAfter(words, 'dev');
    const wireless = dev && (fs.access(`/sys/class/net/${dev}/wireless`)
      || dev.indexOf('wlan') === 0 || dev.indexOf('wl') === 0);
    // 同步路径上 wireless_uplink 是 ubus+shell 调用：原版 detect_uplink
    // 直接调用 wireless_uplink()（同步 ucode call）。JS 侧 bus.call 是
    // 异步，故 detectUplink 只在已有缓存/同步场景用；selfInfo() 用
    // detectUplinkAsync()。此处保留同步签名：无线回程信息由调用方
    // 经 wirelessUplink() 另行取得后传入（见 detectUplinkAsync）。
    return { type: wireless ? 'wireless' : 'wired', port: dev, gw };
  }

  // detect_uplink 的完整异步版：先取无线回程，再按原版规则决定类型。
  // 本插件托管的无线回程已关联时，回程类型以它为准（即使物理上还有网线）。
  async function detectUplinkAsync() {
    const out = cmdOutput(shellCommands.ipRouteDefault());
    const words = String(out.split('\n')[0] ?? '').trim().split(' ');
    const gw = fieldAfter(words, 'via');
    const dev = fieldAfter(words, 'dev');
    const wireless = dev && (fs.access(`/sys/class/net/${dev}/wireless`)
      || dev.indexOf('wlan') === 0 || dev.indexOf('wl') === 0);
    const wl = await wirelessUplink();
    if (wl && (wl.port === BACKHAUL_SECTION || currentBackhaulCfg().enabled)) {
      return {
        type: 'wireless', port: wl.port, gw, ssid: wl.ssid,
        bssid: wl.bssid, rssi: wl.rssi,
      };
    }
    return { type: wireless ? 'wireless' : 'wired', port: dev, gw };
  }

  function selfUptime() {
    return toInt(String(fs.readFile('/proc/uptime') ?? '0').trim().split(' ')[0]);
  }

  function wifiIfaces() {
    const out = [];
    uci.load('wireless');
    uci.foreach('wireless', 'wifi-iface', (s) => {
      if (s.mode && s.mode !== 'ap') return;
      if (s.disabled === '1') return;
      if (s.wifiroam_guest === '1') return; // 访客口不算主人网络
      out.push({
        ssid: s.ssid ?? '',
        encryption: s.encryption ?? 'none',
        band: uci.get('wireless', s.device, 'band') ?? '?',
        device: s.device,
        section: s['.name'],
      });
    });
    return out;
  }

  // 本机各 AP 口的 11k 邻居报告元素：直接取 hostapd 自己生成的 NR
  // （含正确的 op_class / channel / PHY 类型），避免自行推算信道分组
  // 出错，也保证与 AP 实际信道一致（5G 信道在各 AP 上并不相同）。
  async function apNrSelf() {
    const out = [];
    let ws = null;
    try {
      ws = (await busCall('network.wireless', 'status')) ?? {};
    } catch (_e) {
      return out;
    }
    for (const r of Object.values(ws ?? {})) {
      for (const ifc of r.interfaces ?? []) {
        if (!ifc.ifname) continue;
        if (ifc.config?.mode && ifc.config.mode !== 'ap') continue;
        let own = null;
        let st = null;
        try {
          own = await busCall(`hostapd.${ifc.ifname}`, 'rrm_nr_get_own');
          st = await busCall(`hostapd.${ifc.ifname}`, 'get_status');
        } catch (_e) {
          continue;
        }
        const v = own?.value;
        if (!Array.isArray(v) || v.length < 3) continue;
        out.push({
          ifname: ifc.ifname,
          bssid: String(v[0]).toLowerCase(),
          ssid: v[1] ?? '',
          nr: v[2],
          band: toInt(st?.freq ?? 0) < 3000 ? '2g' : '5g',
          channel: st?.channel ?? null,
        });
      }
    }
    return out;
  }

  // 可广播给对端的部分（不含本机网卡名，对端不能直接调用本机 hostapd）
  async function apNrPublic() {
    const out = [];
    for (const e of await apNrSelf()) {
      out.push({
        bssid: e.bssid, ssid: e.ssid, nr: e.nr,
        band: e.band, channel: e.channel,
      });
    }
    return out;
  }

  async function selfInfo() {
    return {
      mac: S.self?.mac, ip: S.self?.ip,
      name: S.self?.name, hostname: S.self?.hostname,
      model: S.self?.model, firmware: S.self?.firmware,
      role: S.cfg?.role, uptime: selfUptime(),
      ifaces: S.self?.ifaces ?? {},
      wifi: wifiIfaces(), uplink: await detectUplinkAsync(),
      nr: await apNrPublic(),
    };
  }

  // ------------------------------------------------------- Wi-Fi 前台设置
  // 读取本机所有 AP 口的 SSID / 是否设了密码，供「无线设置」表单回填。
  // unified 表示「多频合一」：所有 AP 口同名且同密码（密码不对外返回）。
  function wifiSummary() {
    uci.load('wireless');
    const ifaces = [];
    let hasKey = false;
    let unified = true;
    let firstSsid = null;
    let firstKey = null;
    uci.foreach('wireless', 'wifi-iface', (s) => {
      if (s.mode && s.mode !== 'ap') return;
      if (s.wifiroam_guest === '1') return; // 访客网络有独立面板，不参与多频合一判断
      const ssid = s.ssid ?? '';
      const key = s.key ?? '';
      ifaces.push({
        section: s['.name'], device: s.device, ssid,
        encryption: s.encryption ?? 'none',
        band: uci.get('wireless', s.device, 'band') ?? '?',
      });
      if (key !== '') hasKey = true;
      if (firstSsid == null) { firstSsid = ssid; firstKey = key; } else if (ssid !== firstSsid || key !== firstKey) unified = false;
    });
    const first = ifaces[0];
    // 只显示第一组 SSID，多口不一致时标记出来，避免把不同 SSID 合并成假象
    let mixed = false;
    for (const i of ifaces) if (i.ssid !== (first?.ssid ?? '')) mixed = true;
    return {
      ssid: first?.ssid ?? '', has_key: hasKey, mixed,
      unified, ifaces,
    };
  }

  // 改本机全部 AP 口的 SSID 与密码。ssids = [{ band, ssid, key }]，
  // 同频段的接口取同名同密码。某一项的 key 为空表示该频段只改名称、
  // 不动密码。无线重启放在后台：前端请求先返回，避免重启把连接断开
  // 导致界面误判失败。
  function applyWifiLocal(ssids) {
    uci.load('wireless');
    let n = 0;
    uci.foreach('wireless', 'wifi-iface', (s) => {
      if (s.mode && s.mode !== 'ap') return;
      if (s.wifiroam_guest === '1') return; // 访客口由访客面板单独管理
      const band = uci.get('wireless', s.device, 'band') ?? '?';
      let want = null;
      for (const it of ssids ?? []) if (it.band === band) want = it;
      if (want != null && want.ssid !== '') uci.set('wireless', s['.name'], 'ssid', want.ssid);
      if (want != null && want.key !== '') {
        uci.set('wireless', s['.name'], 'key', want.key);
        // 开放网络加密为 none/空时补上 WPA2，否则设了密码也不生效
        const enc = s.encryption ?? '';
        if (enc === '' || enc === 'none') uci.set('wireless', s['.name'], 'encryption', 'psk2');
      }
      n++;
    });
    uci.commit('wireless');
    if (n > 0) cmdOutput(shellCommands.wifiReloadDelayed());
    return { ok: n > 0, count: n };
  }

  // 漫游组里记录的 SSID 必须跟着改名，否则 802.11k/v/r 会因找不到
  // 同名 SSID 失效。pairs = [{ old, new }]：按「旧名 -> 新名」替换，
  // 并把仍是新名的条目补齐，避免两个频段同名时连续重命名把另一个
  // 频段的组从列表里挤掉。
  function roamRenameSsids(pairs) {
    let hit = 0;
    for (const p of pairs ?? []) if (p.old !== '' && p.old !== p.new) hit++;
    if (hit === 0) return;
    uci.load('wifiroam');
    const raw = uci.get('wifiroam', 'roam', 'ssids') ?? [];
    let list = [];
    if (Array.isArray(raw)) list = raw;
    else if (raw !== '') list = [raw];
    const out = [];
    for (const s of list) {
      let mapped = s;
      for (const p of pairs) {
        if (p.old === s && p.new !== '') { mapped = p.new; break; }
      }
      out.push(mapped);
    }
    for (const p of pairs) if (p.new !== '' && !out.includes(p.new)) out.push(p.new);
    // 两个频段并成一组合一时，替换后可能留下重复项
    const dedup = [];
    for (const s of out) if (!dedup.includes(s)) dedup.push(s);
    uci.set('wifiroam', 'roam', 'ssids', dedup);
    uci.commit('wifiroam');
  }

  // ------------------------------------------------------------- 漫游配置
  function rssiPreset(profile) {
    return { aggressive: -62, balanced: -70, conservative: -78 }[profile] ?? -70;
  }

  function currentRoamCfg() {
    uci.load('wifiroam');
    let ssids = [];
    const raw = uci.get('wifiroam', 'roam', 'ssids');
    if (Array.isArray(raw)) ssids = raw;
    else if (typeof raw === 'string' && raw !== '') ssids = [raw];
    let profile = uci.get('wifiroam', 'roam', 'rssi_profile') ?? 'balanced';
    if (!['aggressive', 'balanced', 'conservative', 'custom'].includes(profile)) profile = 'balanced';
    let threshold = toInt(uci.get('wifiroam', 'roam', 'rssi_threshold') ?? rssiPreset(profile));
    if (profile !== 'custom') threshold = rssiPreset(profile);
    if (threshold > -30) threshold = -30;
    if (threshold < -95) threshold = -95;
    return {
      enabled: uci.get('wifiroam', 'roam', 'enabled') === '1',
      ssids,
      // spec §9.3：r_fast 缺失时 `null != "0"` 的 ucode 求值未在规格中
      // 说明；此处按字面比较：缺失（null）时 != "0" 为 true，即默认开。
      r_fast: uci.get('wifiroam', 'roam', 'r_fast') !== '0',
      ft_mode: uci.get('wifiroam', 'roam', 'ft_mode') ?? 'simple',
      ft_over_ds: uci.get('wifiroam', 'roam', 'ft_over_ds') !== '0',
      k_neighbor: uci.get('wifiroam', 'roam', 'k_neighbor') !== '0',
      k_beacon: uci.get('wifiroam', 'roam', 'k_beacon') !== '0',
      v_bss_transition: uci.get('wifiroam', 'roam', 'v_bss_transition') !== '0',
      rssi_profile: profile,
      rssi_threshold: threshold,
      config_ver: toInt(uci.get('wifiroam', 'roam', 'config_ver') ?? '0'),
    };
  }

  // 漫游配置内容签名：SAP 上报本地已落盘配置的签名，CAP 据此判断是否
  // 与主 AP 一致。只比 ver 无法发现历史遗留的不一致（旧版 SAP 只落盘
  // ver/enabled，其他字段仍是默认值）。
  function roamSig(r) {
    return sha256(
      `${r.enabled ? 1 : 0}|${(r.ssids ?? []).join(',')}|${r.r_fast ? 1 : 0}|`
      + `${r.ft_mode ?? 'simple'}|${r.ft_over_ds ? 1 : 0}|${r.k_neighbor ? 1 : 0}|`
      + `${r.k_beacon ? 1 : 0}|${r.v_bss_transition ? 1 : 0}|${r.rssi_profile ?? 'balanced'}|`
      + `${r.rssi_threshold ?? rssiPreset(r.rssi_profile)}`,
    );
  }

  function roamMd(ssid) {
    return sha256(`md:${ssid}`).slice(0, 4);
  }
  function roamKey0(mac) {
    return sha256(`${S.cfg?.token ?? ''}:r0:${macnorm(mac)}`).slice(0, 32);
  }
  function roamKey1(mac) {
    return sha256(`${S.cfg?.token ?? ''}:r1:${macnorm(mac)}`).slice(0, 32);
  }

  function memberList() {
    const members = [{ mac: S.self?.mac, name: S.self?.name }];
    for (const [mn, p] of Object.entries(S.peers ?? {})) {
      if (p.authed) {
        members.push({
          mac: p.mac ?? maccolon(mn),
          name: p.info?.name ?? p.name ?? mn,
        });
      }
    }
    return members;
  }

  function applyRoamLocal(roam, members) {
    uci.load('wireless');
    const touched = [];
    const selfNasid = macnorm(S.self?.mac).toUpperCase();
    uci.foreach('wireless', 'wifi-iface', (s) => {
      if (s.mode && s.mode !== 'ap') return;
      if (s.wifiroam_guest === '1') return;
      const sid = s['.name'];
      const inGroup = roam.enabled && (roam.ssids ?? []).includes(s.ssid);
      if (inGroup) {
        // R（802.11r）可单独关闭：关闭时移除全部 FT 相关键，只保留 K/V
        if (roam.r_fast) {
          uci.set('wireless', sid, 'ieee80211r', '1');
          uci.set('wireless', sid, 'mobility_domain', roamMd(s.ssid));
          uci.set('wireless', sid, 'ft_over_ds', roam.ft_over_ds ? '1' : '0');
          uci.set('wireless', sid, 'reassociation_deadline', '2000');
          if (roam.ft_mode === 'explicit') {
            uci.set('wireless', sid, 'ft_psk_generate_local', '0');
            uci.set('wireless', sid, 'nas_identifier', `${selfNasid}-${s.ssid}`);
            uci.set('wireless', sid, 'pmk_r1_push', '1');
            const r0 = [];
            const r1 = [];
            for (const m of members ?? []) {
              const mm = m.mac;
              r0.push(`${mm},${macnorm(mm).toUpperCase()}-${s.ssid},${roamKey0(mm)}`);
              r1.push(`${mm},${mm},${roamKey1(mm)}`);
            }
            uci.set('wireless', sid, 'r0kh', r0);
            uci.set('wireless', sid, 'r1kh', r1);
          } else {
            uci.set('wireless', sid, 'ft_psk_generate_local', '1');
            for (const k of ['nas_identifier', 'pmk_r1_push', 'r0kh', 'r1kh']) uci.delete('wireless', sid, k);
          }
        } else {
          for (const k of ['ieee80211r', 'mobility_domain', 'ft_over_ds',
            'ft_psk_generate_local', 'reassociation_deadline',
            'nas_identifier', 'pmk_r1_push', 'r0kh', 'r1kh']) uci.delete('wireless', sid, k);
        }
        uci.set('wireless', sid, 'ieee80211k', '1');
        uci.set('wireless', sid, 'rrm_neighbor_report', roam.k_neighbor ? '1' : '0');
        uci.set('wireless', sid, 'rrm_beacon_report', roam.k_beacon ? '1' : '0');
        uci.set('wireless', sid, 'ieee80211v', '1');
        uci.set('wireless', sid, 'bss_transition', roam.v_bss_transition ? '1' : '0');
        touched.push(s.ssid);
      } else {
        // only strip keys we manage, and only if present
        if (uci.get('wireless', sid, 'ieee80211r') != null
          || uci.get('wireless', sid, 'ieee80211k') != null
          || uci.get('wireless', sid, 'ieee80211v') != null) {
          for (const k of ROAM_KEYS) uci.delete('wireless', sid, k);
        }
      }
    });
    uci.commit('wireless');
    S.roam_ver_applied = roam.config_ver ?? S.roam_ver_applied;
    // 整份漫游配置落盘：SAP 的设置页读取本地 uci，只写 ver/enabled 会让
    // 子 AP 显示与主 AP 不一致（SSID 组、FT 模式、k/v 开关等仍是默认值）
    uci.load('wifiroam');
    let dirty = false;
    let wantSsids = roam.ssids ?? [];
    if (!Array.isArray(wantSsids)) wantSsids = wantSsids === '' ? [] : [wantSsids];
    let curSsids = uci.get('wifiroam', 'roam', 'ssids') ?? [];
    if (!Array.isArray(curSsids)) curSsids = curSsids === '' ? [] : [curSsids];
    const want = {
      enabled: roam.enabled ? '1' : '0',
      r_fast: roam.r_fast ? '1' : '0',
      ft_mode: roam.ft_mode === 'explicit' ? 'explicit' : 'simple',
      ft_over_ds: roam.ft_over_ds ? '1' : '0',
      k_neighbor: roam.k_neighbor ? '1' : '0',
      k_beacon: roam.k_beacon ? '1' : '0',
      v_bss_transition: roam.v_bss_transition ? '1' : '0',
      rssi_profile: roam.rssi_profile ?? 'balanced',
      rssi_threshold: String(roam.rssi_threshold ?? rssiPreset(roam.rssi_profile)),
      config_ver: String(S.roam_ver_applied),
    };
    if (curSsids.join('\n') !== wantSsids.join('\n')) {
      uci.set('wifiroam', 'roam', 'ssids', wantSsids);
      dirty = true;
    }
    for (const [k, v] of Object.entries(want)) {
      if ((uci.get('wifiroam', 'roam', k) ?? '') !== v) {
        uci.set('wifiroam', 'roam', k, v);
        dirty = true;
      }
    }
    if (dirty) uci.commit('wifiroam');
    runProcess(...PROC.wifiReload, {
      onExit: (res) => log(`wifi reload rc=${res}`),
    });
    pushEvent('roam_apply', '', `ver=${roam.config_ver ?? 0} ssids=${touched.length}`);
    return { ok: true, touched, ver: S.roam_ver_applied };
  }

  // 本机实际落盘的 K/V/R：随 push_roam_config 回执上报，主AP可显示各 AP 生效状态
  function appliedKvr(ssids) {
    let r = true;
    let k = true;
    let v = true;
    let seen = 0;
    uci.load('wireless');
    uci.foreach('wireless', 'wifi-iface', (s) => {
      if (s.mode && s.mode !== 'ap') return;
      if (s.disabled === '1') return;
      if (s.wifiroam_guest === '1') return;
      if (!(ssids ?? []).includes(s.ssid)) return;
      seen++;
      if (s.ieee80211r !== '1' || (s.mobility_domain ?? '') === '') r = false;
      if (s.ieee80211k !== '1' || (s.rrm_neighbor_report ?? '0') !== '1') k = false;
      if (s.ieee80211v !== '1' || (s.bss_transition ?? '0') !== '1') v = false;
    });
    return { r: seen > 0 && r, k: seen > 0 && k, v: seen > 0 && v, seen };
  }

  // ------------------------------------------------------------- 无线回程
  function wifiRadios() {
    const out = [];
    uci.load('wireless');
    uci.foreach('wireless', 'wifi-device', (s) => {
      out.push({
        name: s['.name'], band: s.band ?? '?',
        disabled: s.disabled === '1',
      });
    });
    return out;
  }

  function pickRadio(prefer) {
    const radios = wifiRadios();
    for (const r of radios) if (!r.disabled && r.name === prefer) return r.name;
    for (const r of radios) if (!r.disabled && r.band === '5g') return r.name;
    for (const r of radios) if (!r.disabled) return r.name;
    return null;
  }

  // 上级 AP 的 MAC 若出现在以太网口上，说明当前仍有有线回程。
  // 此时不能把 STA 桥进 br-lan，否则会形成二层环路；只暂存配置待拔线后自动启用。
  function ethernetUplinkPort() {
    const fdb = parseFdb();
    for (const [mn, p] of Object.entries(S.peers ?? {})) {
      const role = p.info?.role ?? p.role;
      if (role !== 'cap') continue;
      const port = fdb[mn];
      if (port && port.indexOf('phy') !== 0 && port.indexOf('wl') !== 0
        && port.indexOf('vap') !== 0 && port.indexOf('br') !== 0) return port;
    }
    return null;
  }

  function currentBackhaulCfg() {
    uci.load('wifiroam');
    return {
      enabled: uci.get('wifiroam', 'backhaul', 'enabled') === '1',
      ssid: uci.get('wifiroam', 'backhaul', 'ssid') ?? BACKHAUL_DEFAULT_SSID,
      key: uci.get('wifiroam', 'backhaul', 'key') ?? '',
      device: uci.get('wifiroam', 'backhaul', 'device') ?? '',
      config_ver: toInt(uci.get('wifiroam', 'backhaul', 'config_ver') ?? '0'),
    };
  }

  function applyBackhaulLocal(bh, role) {
    uci.load('wireless');
    const exists = uci.get('wireless', BACKHAUL_SECTION) != null;
    if (bh.enabled && (bh.ssid ?? '') !== '' && (bh.key ?? '') !== '') {
      const dev = pickRadio(role === 'cap' ? (bh.device ?? '') : '');
      if (!dev) return { ok: false, error: 'no_radio' };
      // lib/uci.js 的 set() 要求 section 已存在（INTERFACE.md §8.3）；
      // 原版 ucode cursor.set 未写明是否隐式建 section。为使回程口在
      // 首次启用时能落盘，此处先建 section（仅当不存在时），其余写
      // 法与原版逐字一致。
      if (!exists) uci.set('wireless', BACKHAUL_SECTION, 'wifi-iface');
      uci.set('wireless', BACKHAUL_SECTION, 'device', dev);
      uci.set('wireless', BACKHAUL_SECTION, 'mode', role === 'cap' ? 'ap' : 'sta');
      uci.set('wireless', BACKHAUL_SECTION, 'ssid', bh.ssid);
      uci.set('wireless', BACKHAUL_SECTION, 'encryption', 'psk2+ccmp');
      uci.set('wireless', BACKHAUL_SECTION, 'key', bh.key);
      uci.set('wireless', BACKHAUL_SECTION, 'network', 'lan');
      uci.set('wireless', BACKHAUL_SECTION, 'wds', '1');
      if (role === 'cap') {
        uci.set('wireless', BACKHAUL_SECTION, 'hidden', '1');
        uci.set('wireless', BACKHAUL_SECTION, 'disabled', '0');
      } else {
        uci.delete('wireless', BACKHAUL_SECTION, 'hidden');
        uci.set('wireless', BACKHAUL_SECTION, 'disabled',
          ethernetUplinkPort() ? '1' : '0');
      }
    } else if (exists) {
      uci.delete('wireless', BACKHAUL_SECTION);
    }
    uci.commit('wireless');
    const ver = bh.config_ver ?? 0;
    uci.load('wifiroam');
    uci.set('wifiroam', 'backhaul', 'enabled', bh.enabled ? '1' : '0');
    uci.set('wifiroam', 'backhaul', 'ssid', bh.ssid ?? BACKHAUL_DEFAULT_SSID);
    uci.set('wifiroam', 'backhaul', 'key', bh.key ?? '');
    uci.set('wifiroam', 'backhaul', 'device', bh.device ?? '');
    uci.set('wifiroam', 'backhaul', 'config_ver', String(ver));
    uci.commit('wifiroam');
    S.backhaul_ver_applied = ver;
    runProcess(...PROC.wifiReload, {
      onExit: (res) => log(`backhaul wifi reload rc=${res}`),
    });
    pushEvent('backhaul_apply', '', `ver=${ver} ${bh.enabled ? 'wireless' : 'off'}`);
    return { ok: true, ver };
  }

  // SAP 侧：有线/无线回程互斥。网线在位时 STA 保持 disabled，拔线后自动启用；
  // 重新插回网线则暂停 STA，避免二层环路。
  function backhaulTick() {
    if (S.cfg?.role !== 'sap') return;
    const bh = currentBackhaulCfg();
    if (!bh.enabled) return;
    uci.load('wireless');
    if (uci.get('wireless', BACKHAUL_SECTION) == null) return;
    const want = ethernetUplinkPort() ? '1' : '0';
    if ((uci.get('wireless', BACKHAUL_SECTION, 'disabled') ?? '0') === want) return;
    uci.set('wireless', BACKHAUL_SECTION, 'disabled', want);
    uci.commit('wireless');
    pushEvent('backhaul_link', '',
      want === '1' ? 'wired uplink detected, wireless STA paused'
        : 'cable removed, wireless backhaul enabled');
    runProcess(...PROC.wifiReload, {
      onExit: (res) => log(`backhaul switch rc=${res}`),
    });
  }

  // --------------------------------------------------------------- 预检查
  function ssidGroups() {
    const groups = {};
    const selfMn = macnorm(S.self?.mac);
    for (const w of wifiIfaces()) {
      const g = groups[w.ssid] ?? (groups[w.ssid] = { ssid: w.ssid, aps: {}, encs: {}, bands: {} });
      g.aps[selfMn] = true;
      g.encs[selfMn] = w.encryption;
      g.bands[w.band] = true;
    }
    for (const [mn, p] of Object.entries(S.peers ?? {})) {
      for (const w of p.info?.wifi ?? []) {
        const g = groups[w.ssid] ?? (groups[w.ssid] = { ssid: w.ssid, aps: {}, encs: {}, bands: {} });
        g.aps[mn] = true;
        g.encs[mn] = w.encryption;
        g.bands[w.band] = true;
      }
    }
    const out = [];
    for (const [ssid, g] of Object.entries(groups)) {
      const encset = {};
      for (const e of Object.values(g.encs)) encset[e] = true;
      const encList = Object.keys(encset);
      let encOk = true;
      for (const e of encList) if (e.indexOf('psk') < 0 && e.indexOf('sae') < 0) encOk = false;
      out.push({
        ssid, ap_count: Object.keys(g.aps).length,
        bands: Object.keys(g.bands), encryptions: encList,
        consistent: encList.length === 1,
        enc_ok: encOk,
      });
    }
    return out;
  }

  // 全网络 AP 概览：CAP 汇总后下发给 SAP，子 AP 的“开启前检查”与主 AP 保持一致
  function apOverview() {
    const selfMn = macnorm(S.self?.mac);
    const aps = [{
      id: selfMn, name: S.self?.name, role: S.cfg?.role,
      ip: S.self?.ip, online: true, self: true,
      ssids: wifiIfaces().map((w) => w.ssid),
      // 本机实际落盘的 K/V/R，便于主 AP 与子 AP 看到一致的生效状态
      kvr: appliedKvr(currentRoamCfg().ssids),
    }];
    for (const [mn, p] of Object.entries(S.peers ?? {})) {
      const list = [];
      for (const w of p.info?.wifi ?? []) if (!list.includes(w.ssid)) list.push(w.ssid);
      aps.push({
        id: mn, name: p.info?.name ?? p.name ?? maccolon(mn),
        role: p.info?.role ?? p.role ?? 'sap',
        ip: p.info?.ip ?? p.ip, online: !!p.authed, self: false,
        ssids: list,
        kvr: p.kvr ?? null,
      });
    }
    return { groups: ssidGroups(), aps };
  }

  function precheck() {
    const checks = [];
    // apk (24.10+) / opkg (legacy) 双栈检测
    let wp = '';
    if (fs.access('/usr/bin/apk') || fs.access('/sbin/apk')) {
      wp = cmdOutput(shellCommands.wpadApk()).trim();
    }
    if (wp === '') wp = cmdOutput(shellCommands.wpadOpkg()).trim();
    checks.push({
      id: 'wpad', ok: wp !== '' && wp.indexOf('basic') < 0,
      info: wp !== '' ? wp : 'none',
    });
    // SAP 用 CAP 下发的全网络概览，避免子 AP 只看到本机接口导致计数/状态不一致
    const overview = (S.cfg?.role === 'sap' && S.roster?.aps) ? S.roster : apOverview();
    const groups = overview.groups;
    let nMulti = 0;
    for (const g of groups) if (g.ap_count >= 2) nMulti++;
    checks.push({ id: 'ssid_group', ok: nMulti > 0, info: String(nMulti) });
    for (const g of groups) {
      checks.push({ id: 'enc_consistent', ok: g.consistent, info: `${g.ssid}: ${g.encryptions.join(',')}` });
      checks.push({ id: 'enc_allowed', ok: g.enc_ok, info: `${g.ssid}: ${g.encryptions.join(',')}` });
    }
    checks.push({ id: 'role', ok: S.cfg?.role === 'cap', info: S.cfg?.role });
    // 成员 AP 概览：让“开启前检查”能直接看出子路由上报的 SSID/频段是否正确，
    // 而不是只显示一个汇总计数
    // self 标记必须按本机 MAC 重新计算：CAP 下发的 roster 里 "self" 指 CAP 自己
    const selfMn = macnorm(S.self?.mac);
    const aps = [];
    for (const a of overview.aps) {
      aps.push({
        id: a.id, name: a.name, role: a.role, ip: a.ip,
        online: a.online, self: a.id === selfMn, ssids: a.ssids,
        kvr: a.kvr ?? null,
      });
    }
    return { checks, groups, role: S.cfg?.role, aps };
  }

  // ------------------------------------------------------- 11k 邻居与引导
  function steerBssList() {
    return (async () => {
      const out = [];
      const seen = {};
      for (const e of await apNrSelf()) {
        out.push(e);
        seen[`${String(e.bssid).toLowerCase()}|${e.ssid}`] = true;
      }
      const others = [];
      for (const p of Object.values(S.peers ?? {})) {
        for (const e of p.info?.nr ?? []) others.push(e);
      }
      for (const e of S.cap_nr ?? []) others.push(e);
      for (const e of others) {
        if (e?.bssid == null || e?.nr == null) continue;
        const k = `${String(e.bssid).toLowerCase()}|${e.ssid ?? ''}`;
        if (seen[k]) continue;
        seen[k] = true;
        out.push({
          bssid: String(e.bssid).toLowerCase(), ssid: e.ssid ?? '',
          nr: e.nr, band: e.band, channel: e.channel,
        });
      }
      return out;
    })();
  }

  // 全拓扑视角的 BSS 列表（去掉本机网卡名）。CAP 用它在 report_status
  // 回执里下发候选：SAP 之间没有直连通道，只能经 CAP 交换，否则各自
  // 只认识 CAP，邻居库里缺少另一台 SAP，终端也就看不到那台更近的 AP。
  async function bssPublic() {
    const out = [];
    for (const e of await steerBssList()) {
      out.push({
        bssid: e.bssid, ssid: e.ssid, nr: e.nr,
        band: e.band, channel: e.channel,
      });
    }
    return out;
  }

  // 把其它 AP 的同 SSID BSS 写进本机 hostapd 的 11k 邻居库。终端主动发
  // BSS Transition Query 询问候选时，hostapd 才有内容可答；邻居库为空时
  // 手机只能自己扫描，华为/荣耀等机型往往干脆不动。
  async function neighborSync(bsses) {
    let sig = '';
    for (const e of bsses) sig += `${e.ssid}|${e.bssid};`;
    if (sig === S.nr_sig) return;
    S.nr_sig = sig;
    for (const e of bsses) {
      if (!e.ifname) continue; // 只有本机接口能调用
      const list = [];
      for (const o of bsses) {
        if (o.ssid !== e.ssid) continue;
        if (String(o.bssid).toLowerCase() === String(e.bssid).toLowerCase()) continue;
        if (o.nr == null || o.nr === '') continue;
        list.push([o.bssid, o.ssid, o.nr]);
      }
      if (!list.length) continue;
      try {
        await busCall(`hostapd.${e.ifname}`, 'rrm_nr_set', { list });
      } catch (_err) {
        log(`nr_set ${e.ifname} failed`);
      }
    }
  }

  // 信号低于阈值时，通过 hostapd 的 BSS Transition Management 主动引导
  // 终端切换到更合适的 AP。CAP/SAP 各自对自己下挂的终端执行，避免跨节点转发。
  // 关键点：BTM 请求必须带候选列表（neighbors）。没有候选时多数手机
  // （华为/荣耀/部分 IoT）会直接忽略请求，表现为“信号很差也不切换”。
  async function steerTick() {
    if (S.cfg?.role === 'unconfigured') return;
    const roam = currentRoamCfg();
    if (!roam.enabled || !roam.v_bss_transition) return;
    const threshold = roam.rssi_threshold;
    if (threshold == null || threshold >= 0) return;
    if (!roam.ssids.length) return;
    let hasPeer = false;
    for (const p of Object.values(S.peers ?? {})) {
      if (p.authed) { hasPeer = true; break; }
    }
    if (!hasPeer) return; // 单 AP 无处分流，引导只会让终端掉线
    const selfNr = await apNrSelf();
    const bsses = await steerBssList();
    if (roam.k_neighbor) await neighborSync(bsses);
    const now = nowSeconds();
    const clients = await localClients();
    for (const [mn, c] of Object.entries(clients ?? {})) {
      if (c.type !== 'wifi' || !c.ifname) continue;
      // 固定 AP 的终端完全退出自动引导：钉在本 AP 时信号再差也不迁走
      if (pinOf(mn)) { delete S.steer_tries[mn]; continue; }
      if (c.ssid == null || !roam.ssids.includes(c.ssid)) continue;
      const rssi0 = c.rssi;
      if (rssi0 == null) continue;
      const rssi = toInt(rssi0);
      if (rssi >= threshold) { delete S.steer_tries[mn]; continue; }
      // 刚入网（含刚被引导成功）时先观察，同时清零失败计数
      if (c.connected_time != null && toInt(c.connected_time) < MIN_STEER_ASSOC) {
        delete S.steer_tries[mn];
        continue;
      }
      // 候选：同 SSID 的其它 BSS（排除终端当前所在的 BSS）
      let curBssid = null;
      for (const e of selfNr) if (e.ifname === c.ifname) curBssid = String(e.bssid).toLowerCase();
      const candNr = [];
      let cand = 0;
      for (const e of bsses) {
        if (e.ssid !== c.ssid) continue;
        if (curBssid != null && String(e.bssid).toLowerCase() === curBssid) continue;
        if (e.nr == null || e.nr === '') continue;
        candNr.push(e.nr);
        cand++;
      }
      if (!cand) { delete S.steer_tries[mn]; continue; }
      if (now - (S.steer_last[mn] ?? 0) < STEER_COOLDOWN) continue;
      const tries = S.steer_tries[mn] ?? 0;
      if (tries >= STEER_KICK_AFTER) {
        // 刚被踢过又回到原 AP，说明附近没有更强的 AP，别再反复踢
        if ((S.steer_mute[mn] ?? 0) > now) continue;
        try {
          await busCallThrow(`hostapd.${c.ifname}`, 'del_client', {
            addr: maccolon(mn), deauth: true, reason: 1, ban_time: 0,
          });
          S.kick_last[mn] = now;
          S.steer_mute[mn] = now + STEER_KICK_COOLDOWN;
          S.steer_tries[mn] = 0;
          S.steer_last[mn] = now;
          pushEvent('roam_kick', maccolon(mn),
            `rssi=${rssi} < ${threshold}`, clientNameOf(mn, clients));
        } catch (_e) {
          log(`kick ${mn} failed`);
        }
        continue;
      }
      try {
        await busCallThrow(`hostapd.${c.ifname}`, 'bss_transition_request', {
          addr: maccolon(mn),
          disassociation_imminent: true,
          disassociation_timer: 10,
          validity_period: 30,
          abridged: false,
          neighbors: candNr,
        });
        S.steer_last[mn] = now;
        S.steer_tries[mn] = tries + 1;
        pushEvent('roam_steer', maccolon(mn),
          `rssi=${rssi} < ${threshold} cand=${cand}`, clientNameOf(mn, clients));
      } catch (_e) {
        log(`steer ${mn} failed`);
      }
    }
  }

  // 固定 AP 的本机执行：连到非目标 AP 的终端直接断开并禁入一段时间
  // （pin 关系经 ctx.pinOf 读 clients 的实现）。
  async function pinTick() {
    if (S.cfg?.role === 'unconfigured') return;
    const pin = S.aliases?.pin;
    if (!pin || !Object.keys(pin).length) return;
    const selfMn = macnorm(S.self?.mac);
    const now = nowSeconds();
    const clients = await localClients();
    for (const [mn, c] of Object.entries(clients ?? {})) {
      if (c.type !== 'wifi' || !c.ifname) continue;
      const ap = pinOf(mn);
      if (!ap || ap === selfMn) continue;
      if (now - (S.pin_last?.[mn] ?? 0) < PIN_KICK_COOLDOWN) continue;
      try {
        await busCallThrow(`hostapd.${c.ifname}`, 'del_client', {
          addr: maccolon(mn), deauth: true, reason: 1,
          ban_time: PIN_BAN_MS,
        });
        S.pin_last[mn] = now;
        pushEvent('pin_kick', maccolon(mn),
          `${apDisplay(selfMn)} → ${apDisplay(ap)}`, clientNameOf(mn, clients));
      } catch (_e) {
        log(`pin kick ${mn} failed`);
      }
    }
  }

  // ------------------------------------------------- 首次启用默认漫游
  // 插件启用后按默认设置开启漫游：首次启动（从未保存过漫游配置）时，
  // 自动选中本机全部主网络 SSID，并按默认 k/v/r 参数下发一次。
  function roamDefaultInit() {
    uci.load('wifiroam');
    if (toInt(uci.get('wifiroam', 'roam', 'config_ver') ?? '0') !== 0) return;
    if (uci.get('wifiroam', 'roam', 'enabled') !== '1') return;
    const raw = uci.get('wifiroam', 'roam', 'ssids');
    if (Array.isArray(raw) ? raw.length > 0 : (raw ?? '') !== '') return;
    const ssids = [];
    for (const w of wifiIfaces()) {
      if (w.ssid !== '' && !ssids.includes(w.ssid)) ssids.push(w.ssid);
    }
    if (!ssids.length) return;
    uci.set('wifiroam', 'roam', 'ssids', ssids);
    uci.set('wifiroam', 'roam', 'config_ver', '1');
    uci.commit('wifiroam');
    const roam = currentRoamCfg();
    applyRoamLocal(roam, memberList());
    S.last_apply = {
      ts: nowSeconds(), ver: roam.config_ver,
      results: [{
        ap: S.self?.mac, name: S.self?.name,
        ok: true, ver: roam.config_ver,
        kvr: appliedKvr(roam.ssids),
      }],
    };
    log(`roam defaults enabled for ${ssids.length} SSID(s)`);
  }

  return {
    // 常量
    STEER_COOLDOWN, MIN_STEER_ASSOC, STEER_KICK_AFTER, STEER_KICK_COOLDOWN,
    PIN_BAN_MS, PIN_KICK_COOLDOWN, BACKHAUL_SECTION, BACKHAUL_DEFAULT_SSID,
    ROAM_KEYS,
    // 自检 / 探测
    lanBroadcast, localIfaceMacs, detectSelf, wirelessUplink, detectUplink,
    detectUplinkAsync, selfUptime, selfInfo, apNrSelf, apNrPublic,
    // Wi-Fi 前台
    wifiIfaces, wifiSummary, applyWifiLocal, roamRenameSsids,
    // 漫游
    rssiPreset, currentRoamCfg, roamSig, roamMd, roamKey0, roamKey1,
    memberList, applyRoamLocal, appliedKvr, roamDefaultInit,
    // 回程
    wifiRadios, pickRadio, ethernetUplinkPort, currentBackhaulCfg,
    applyBackhaulLocal, backhaulTick,
    // 预检查
    ssidGroups, apOverview, precheck,
    // 邻居与引导
    steerBssList, bssPublic, neighborSync, steerTick,
    // 固定 AP（本机执行；pin 读/写实现在 clients，本模块只调 ctx.pinOf）
    pinTick,
  };
}
