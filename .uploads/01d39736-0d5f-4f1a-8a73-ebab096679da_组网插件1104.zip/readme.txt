四个安装文件上传的路由器目录下，执行如下安装命令安装即可

apk add --allow-untrusted ucode-mod-socket*.apk wifiroam-*.apk luci-app-wifiroam-*.apk luci-i18n-wifiroam-zh-cn-*.apk
